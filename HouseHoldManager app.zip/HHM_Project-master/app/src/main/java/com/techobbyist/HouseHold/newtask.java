package com.techobbyist.HouseHold;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by Ramzy on 2017-11-29.
 */

public class newtask extends AppCompatActivity implements View.OnClickListener {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addnewtask);

    }

    @Override
    public void onClick(View view) {
        //...
    }
}
